import React from 'react'

// ! This is the social feed
// * List of all posts in time order 
// * Image with caption 
// * Button to like
// * Button to comment
// * If you click on their profile image it will take you to their profile

const Fernstagram = () => {
  return <h1>hello fernstagram</h1>
}

export default Fernstagram