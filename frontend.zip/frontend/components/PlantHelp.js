import React from 'react'

// ! Stand alone page for plant keeping tips

const PlantHelp = () => {
  return <h1>hello planthelp</h1>
}

export default PlantHelp