import React from 'react'

// !Wishlist of a User

const Wishlist = () => {
  return <h1>hello wishlist</h1>
}

export default Wishlist