import React, { useState, useEffect} from 'react'
import axios from 'axios'

// * Image 
// * Outdoor plant 
// * Plant type
// * User notes
// * Confirmation button takes you back to personal plant page

const EditPlant = (props) => {
const plantId = props.match.params.plantId




  { console.log(props) }
  return <h1>hello editplant</h1>
}

export default EditPlant