import React from 'react'

const PlantSitters = () => {
  return <h1>hello plantsitters</h1>
}

export default PlantSitters