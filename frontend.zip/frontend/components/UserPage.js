import React from 'react'

// ! User Page
// * Name 
// * Image
// * Badges 
// * Status 
// * Plant count 
// * User bio 
// * Contact button 
// * List of the users plants 

// ? Ability to see users plants and posts
// ? Link to add more plants
// ? Link to see messages


const UserPage = () => {
  return <h1>hello userpage</h1>
}

export default UserPage