import React from 'react'

// ! Map Page
// * Centers on Logged in user
// * Map Icons for other users

const UserMap = () => {
  return <h1>hello usermap</h1>
}

export default UserMap